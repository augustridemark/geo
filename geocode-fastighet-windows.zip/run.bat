@echo off
REM ===================================================================
REM  Windows launcher for geocode_fastighet.py
REM  First run creates a local .venv and installs dependencies.
REM  Later runs just execute the script.
REM
REM  Output files are created automatically with a timestamped name.
REM
REM  Examples:
REM     run.bat "emmaboda emmabo 1:116"
REM     run.bat fastigheter.csv
REM     run.bat --geojson fastigheter.csv
REM     run.bat --gpkg fastigheter.csv
REM     run.bat --geojson --gpkg fastigheter.csv
REM ===================================================================
setlocal

set "HERE=%~dp0"
set "VENV=%HERE%.venv"
set "PYEXE=%VENV%\Scripts\python.exe"

if "%~1"=="" (
    echo(
    echo Geocode Swedish fastighetsbeteckningar to WGS84 coordinates.
    echo Timestamped output files are created automatically ^(.csv always;
    echo add --geojson and/or --gpkg for those too^).
    echo(
    echo Usage:  run.bat [--geojson] [--gpkg] [--delay SECONDS] ^<beteckning ^| file.csv^>
    echo(
    echo Examples:
    echo     run.bat "emmaboda emmabo 1:116"
    echo     run.bat fastigheter.csv
    echo     run.bat --geojson --gpkg fastigheter.csv
    echo(
    pause
    exit /b 0
)

REM Set up the environment on first run; send its output to stderr so a
REM redirected stdout (e.g. "> out.csv") is not polluted by pip logs.
if not exist "%PYEXE%" call :setup 1>&2
if not exist "%PYEXE%" exit /b 1

"%PYEXE%" "%HERE%geocode_fastighet.py" %*
exit /b %errorlevel%

:setup
echo Setting up Python environment (first run only, this may take a minute)...
py -3 -m venv "%VENV%" 2>nul
if not exist "%PYEXE%" python -m venv "%VENV%" 2>nul
if not exist "%PYEXE%" (
    echo(
    echo ERROR: Python was not found. Install Python 3.11 or newer from
    echo    https://www.python.org/downloads/    ^(tick "Add python.exe to PATH"^)
    echo then run this file again.
    pause
    exit /b 1
)
"%PYEXE%" -m pip install --upgrade pip
"%PYEXE%" -m pip install -r "%HERE%requirements.txt"
exit /b 0
