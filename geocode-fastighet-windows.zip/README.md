# Fastighet geocoder

Look up WGS84 (latitude/longitude) coordinates and parcel boundaries for Swedish
*fastighetsbeteckningar* via Lantmäteriet's Min karta service.

Input is a single beteckning or a **CSV file** (header row, beteckningar in the first
column). A **timestamped CSV** (a representative point per property) is always written;
add `--geojson` and/or `--gpkg` to also write those formats.

## Running on Windows

**Requirements:** Python 3.11+ ([python.org/downloads](https://www.python.org/downloads/) —
during install, tick *"Add python.exe to PATH"*).

**Easiest way** — use `run.bat`. Open a Command Prompt in this folder and run, for example:

```bat
run.bat "emmaboda emmabo 1:116"
run.bat fastigheter-example.csv
run.bat --geojson fastigheter-example.csv
run.bat --gpkg fastigheter-example.csv
run.bat --geojson --gpkg fastigheter-example.csv
```

The **first** run automatically creates a local `.venv` folder and installs the
dependency needed for GeoPackage export (takes a minute). Every run after that is instant.

You can also just double-click `run.bat` to see the usage help.

## Output

Files are written automatically with a **timestamped name**, next to the input CSV
(or in the current folder for a string input), e.g. `fastigheter_20260707_164912.csv`:

| Flag              | File written                                                  |
| ----------------- | ------------------------------------------------------------- |
| *(always)*        | `.csv` — `input,matched,lat,lon,status` (representative point) |
| `--geojson`       | `.geojson` — FeatureCollection with a boundary polygon each   |
| `--gpkg`          | `.gpkg` — OGC GeoPackage MultiPolygon layer (WGS84)           |

The flags are additive — use either, both, or neither. `--delay SECONDS` sets the pause
between lookups (default `0.15`).

- **CSV and GeoJSON need no installation** — with Python on PATH you can also run them
  directly: `python geocode_fastighet.py fastigheter-example.csv`
- **GeoPackage (`--gpkg`) needs `geopandas`**, which `run.bat` installs for you.

## Notes

- Open the `.gpkg` in [QGIS](https://qgis.org) (free) or an online viewer such as
  [QuickMapTools](https://www.quickmaptools.com/show-geopackage).
- The `status` column flags rows that are `approx` (no exact name match) or `not found`.
- Requests retry automatically on rate limits (HTTP 429) with backoff, so a big batch
  slows down rather than losing rows.

## Files to copy to the Windows machine

Copy these (do **not** copy any `.venv` folder created on another OS):

```
geocode_fastighet.py
run.bat
requirements.txt
README.md
fastigheter-example.csv   (optional sample)
```
